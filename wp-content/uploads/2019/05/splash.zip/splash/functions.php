<?php

$theme_info = wp_get_theme();
$splash_inc_path = get_template_directory() . '/includes';
$splash_partials_path = get_template_directory() . '/partials';
$splash_widgets_path = get_template_directory() . '/includes/widgets';

define( 'STM_CUSTOMIZER_PATH', get_template_directory() . '/includes/customizer' );
define( 'STM_CUSTOMIZER_URI', get_template_directory_uri() . '/includes/customizer' );
define( 'SPLASH_THEME_VERSION', ( WP_DEBUG ) ? time() : $theme_info->get( 'Version' ) );

// Product Registration
if(is_admin()) {
	require_once(get_template_directory() . '/admin/admin.php');
	require_once(get_template_directory() . '/includes/megamenu/megamenu_config.php');
	require_once(get_template_directory() . '/includes/admin/announcement/main.php');


    add_action('in_admin_footer', 'add_current_theme', 100);

}
function add_current_theme() {

    $curLayout = (is_layout('baseball')) ? 'bsbl' : '';
	if(!empty($curLayout)){
		echo '<script> var currentTheme = ' . $curLayout . '</script>';
	}
    else {
	    echo '<script> var currentTheme; </script>';
    }
}

//Theme options.
require_once($splash_inc_path . '/class/Customizer_Additional.php');
require_once (STM_CUSTOMIZER_PATH . '/customizer.class.php');

// Custom code and theme main setups.
require_once( $splash_inc_path . '/setup.php' );

// Enqueue scripts and styles for theme.
require_once( $splash_inc_path . '/enqueue.php' );

// Ajax actions.
require_once( $splash_inc_path . '/ajax-actions.php' );

// Custom code for any outputs modifying.
require_once( $splash_inc_path . '/custom.php' );

function sportspress_pro_url_theme_8( $url ) {
	return add_query_arg( 'theme', '8', $url );
}

function check_some_other_plugin() {
    if(is_plugin_active('sportspress/sportspress.php')) {
        add_filter( 'sportspress_pro_url', 'sportspress_pro_url_theme_8' );
    }
}
add_action( 'admin_init', 'check_some_other_plugin' );

// Required plugins for the theme.
require_once( $splash_inc_path . '/tgm/tgm-plugin-registration.php' );

require_once $splash_inc_path . '/megamenu/main.php';

// Visual composer custom modules
if ( defined( 'WPB_VC_VERSION' ) ) {
	require_once( $splash_inc_path . '/visual_composer.php' );
}

/*Woocommerce setups*/
if( class_exists( 'WooCommerce' ) ) {
	require_once( $splash_inc_path . '/woocommerce.php' );
}

/*Menu Walker*/
require_once( $splash_inc_path . '/class/Split_Menu_Walker.php' );

/*Partials functions*/
/*Media single*/
require_once( $splash_partials_path . '/loop/media-content.php' );
require_once( $splash_partials_path . '/loop/media-content-3-x-3.php' );

/*WIDGETS*/
require_once( $splash_widgets_path . '/contacts.php' );
require_once( $splash_widgets_path . '/stm-event-list.php' );
require_once( $splash_widgets_path . '/recent_posts.php' );
require_once( $splash_widgets_path . '/follow_us.php' );

add_filter('woocommerce_save_account_details_required_fields', 'wc_save_account_details_required_fields' );
function wc_save_account_details_required_fields( $required_fields ){
	unset( $required_fields['account_display_name'] );
	return $required_fields;
}