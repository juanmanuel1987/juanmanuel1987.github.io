<?php if(!is_layout('magazine_one') && !is_layout('soccer_two')) get_template_part('partials/global/title-box'); ?>

<?php the_content(); ?>