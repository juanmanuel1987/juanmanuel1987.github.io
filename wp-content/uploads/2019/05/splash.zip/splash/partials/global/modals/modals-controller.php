<?php

/*Donation modal*/
if(is_singular(array('donation'))) {
	get_template_part('partials/global/modals/donation');
}