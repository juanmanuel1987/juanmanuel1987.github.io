Splash readme file

http://stylemixthemes.com